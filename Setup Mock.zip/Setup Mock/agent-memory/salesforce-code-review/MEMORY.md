# Code Review Agent Memory

## Project-Specific Patterns

### Trigger Gate Pattern — flowControll class
The project uses a `flowControll` class with static boolean flags (e.g., `flowControll.opportunityTriggerHandler`) to gate trigger logic. This is the project standard for declarative on/off control. Do NOT flag this as non-standard or as missing recursion prevention — it IS the recursion/bypass mechanism.

### ShGl_DisableBusinessLogic__c in Test Classes
Test classes in this project insert `ShGl_DisableBusinessLogic__c` records via `suppressTriggers()` helpers to prevent side-effect triggers from firing during data setup. This is intentional and correct — do NOT flag it as test isolation concern.

### Opportunity Record Type Filter
This org uses multiple Opportunity record types. When reviewing Opportunity queries, check whether `AND RecordType.Name = 'Sales Opportunity'` is present when the design requires it. Missing this filter is a WARNING — it can surface non-sales records as business data.

### Wire Error Handling Gap
Across this project's LWC components, wire adapters (`_case`, `_comments`, `_contractInfo`) do not surface the `.error` property in the UI. Flagging the error property omission on new wire adapters added to rubrikCaseDemo.js is valid (WARNING level). Pre-existing wires are out of scope for per-feature reviews.

### ServiceContract as Product Source
This project uses `ServiceContract` records (not Assets or Products) as the source for "Products Owned" chips. `ServiceContract.Description` is used as the product display name with a fallback to `'Product'`. This is a deliberate workaround pending design clarification — flag it as SUGGESTION (not CRITICAL) when reviewing related code.

### for:each Key Uniqueness
When `ServiceContract.Description` is null, the product chip key falls back to the string literal `'Product'`, which is non-unique. Flag this as WARNING when reviewing LWC product chip iterations keyed on `p.name` without a unique fallback.
