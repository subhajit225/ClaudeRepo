# Salesforce Design Agent Memory

## Project Conventions
- API Version: 66.0
- Package Directory: force-app/main/default
- Quote Object: SBQQ__Quote__c (Salesforce CPQ managed package)
- Primary Contact on Quote: SBQQ__PrimaryContact__c (managed) gets copied to Primary_Contact__c (custom) by QuoteTriggerHelper.cls trigger logic. Use Primary_Contact__c for queries.
- Trigger bypass: TriggerControls class + ShGl_DisableBusinessLogic__c custom setting
- Controller pattern: `with sharing` for all service classes

## Codebase Knowledge
- [Quote Portal Details](quote-portal.md) - RubrikQuotePortal VF page and controller details
- OVF__c object EXISTS (Order Verification Form) - Lookup to SBQQ__Quote__c, AutoNumber name
- RubrikQuoteLookupController.cls serves the OVF portal (validates quote# + email, submits OVF records)
- OVF portal URL (sandbox): https://rubrikinc--claudepoc.sandbox.my.salesforce-sites.com/rubrikquote
- [CPQ SW-without-HW Validation](cpq-sw-without-hw.md) - Detailed mapping of the "SW without HW" validation logic

## Classification Patterns
- VF page modifications = Development work
- Apex controller modifications = Development work
- Custom object + field creation = Admin work
- Quick action metadata (.quickAction-meta.xml) = Admin work
- LWC + Apex controller for quick action = Development work
- When a request mixes object creation with code changes, Admin must go first (object must exist before Apex references it)
- LWC-backed quick actions: Admin creates the quickAction metadata, Dev creates the LWC + Apex

## Existing Patterns for Reference
- LWC quick actions: lCC_Credit_SDR_ISR_Opportunity_LWC (uses @api recordId, CloseActionScreenEvent)
- Email sending: QuoteTriggerHelperForEmail.cls (Messaging.SingleEmailMessage, setHtmlBody)
- Quote line item fields: SBQQ__Product__r.Name, SBQQ__Quantity__c, SBQQ__ListPrice__c, SBQQ__NetTotal__c
- TriggerHandler base class used for trigger handler pattern
- Email file attachments: renewalDocumentationController.cls lines 187-193 (Messaging.EmailFileAttachment + setFileAttachments)
- Latest QuoteDocument query: GenerateDocumentCustomExt.cls line 71 (ORDER BY CreatedDate DESC LIMIT 1)
- CPQ Quote Document PDF storage: May be ContentVersion (Files) or classic Attachment -- org uses both patterns
- Send OVF implementation: SendOvfEmailController.cls (Apex) + sendOvfQuickAction LWC + SBQQ__Quote__c.Send_OVF.quickAction-meta.xml
- OVF__c has 15 form fields (all Text 255, none required): Buyer_Name__c, Buyer_Billing_ID__c, Buyer_Tenant_ID__c, Reseller_Name__c, Marketplace_Seller_ID__c, Company_Name__c, Address_1__c, Address_2__c, City__c, State__c, Zip_Code__c, Country__c, Contact_Name__c, Contact_Email__c, Contact_Phone__c
- OVF__c also has 5 additional fields (Text 100): Customer_AWS_Account_ID__c, Purchase_Amount__c, Company_Name_in_Tackle__c, Billing_Subaccount__c, Customer_Name_in_POA__c
- SBQQ__Quote__c.Name holds the quote number (e.g., "Q-825189") -- used for matching in ShipmentDetailHandler and RubrikQuoteLookupController
- No Lightning Tabs or Lightning Apps exist in local source repo (tabs/ and applications/ directories are empty)
- OVF__c marketplace ID naming pattern: Customer_AWS_Account_ID__c (Text 100) -- follow this for new marketplace ID fields
- RubrikQuotePortal.page: applyHtmlTag=false, applyBodyTag=false, uses VF Remoting (@RemoteAction), matrix rain animation, split layout, guest user access via Site
- GuestDmlHelper (without sharing inner class in controller) handles DML for guest user context
- GuestQueryHelper (without sharing inner class in controller) handles SOQL for guest user context

## Trigger Handler Framework
- Base class: TriggerHandler.cls (Kevin O'Hara pattern, github.com/kevinohara80/sfdc-trigger-framework)
- Trigger calls: new XxxHandler().run() -- run() dispatches to beforeInsert(), afterUpdate(), etc.
- Handler extends TriggerHandler, overrides the events it needs
- Constructor pattern: setMaxLoopCount(2) for prod, 25 for test (see POStageHandler constructor)
- Bypass: TriggerControl__c.getInstance('ObjectName')?.DisableTrigger__c
- Kill switch: ShGl_DisableBusinessLogic__c custom setting (object-specific fields like Disable_StagePO_Trigger__c)
- No existing OVF trigger or handler in codebase
- Existing Queueable pattern: simple class implements Queueable, constructor takes Set<Id>, execute() does work

## PO_Stage__c (Stage PO) Key Facts
- POStageTrigger -> POStageHandler -> POStageHelper
- POStageHelper.populateQuoteDetails() auto-populates Quote__c, LineCount__c, IsQuotePrimary__c, Opportunity_Owner_LK__c, Opportunity__c from Quote_number__c on beforeInsert/beforeUpdate
- PO_Validation_Status__c picklist values: Success, Failure, Pending (default), Invalid, Staged, plus several 855-related values
- Quote__c: Lookup to SBQQ__Quote__c (SetNull, not required)
- Quote_number__c: Text(100) -- the key field that triggers auto-population
- No OVF__c reference exists on PO_Stage__c

## Design Decision Log
- OVF dynamic fieldset: Chose inline <apex:repeat> over @RemoteAction for fieldset metadata (avoids extra round-trip, no guest remoting permission issues)
- OVF dynamic submit: Chose new submitOVFDynamic(quoteId, fieldValuesJson) method rather than modifying existing 16-param submitOVF (backward compat)
- LWC folder rename: Keep existing folder names when refactoring LWC. Renaming requires create-new + delete-old (no rename in metadata API), breaks tab/flexi page references, risks orphaned metadata. User-facing labels can be updated independently.
- MDT for config-driven logic: Marketplace_Column_Mapping__mdt pattern -- store CSV column-to-field mappings keyed by marketplace. Admin deploys MDT first, then dev code references it. MDT records accessible in test context without SeeAllData.
- Marketplace field naming: User mandates Marketplace_* prefix for ALL marketplace-sourced fields. Existing fields without prefix (Subscription_End_Date__c, Subscription_Start_Date__c, Buyer_Tenant_ID__c) are Site-sourced -- do NOT reuse for marketplace data. Create new Marketplace_* fields instead.
- Error_Logs__c reuse: Existing integration log object (label "Integration Log", IGL-{00000000}) is preferred for logging. Fields: Class__c, Method__c, Object__c (label "Description"), Error_Message__c (LTA 130768), Success__c (Checkbox), Type__c (Picklist, use "Integration"). UtilityClass.cls has logging helpers.
- Email Service classes must be `global with sharing` (Salesforce requirement for InboundEmailHandler)
- Email Service routing config is NOT deployable via metadata -- must include manual setup steps in documentation

## Refactoring Patterns
- When creating a new generic version of an existing class, create new file and leave old file untouched (user explicitly said "old file stays for now")
- Admin work (MDT object+fields+records) must deploy before dev work when Apex queries the MDT
- Custom Metadata seed records go in force-app/main/default/customMetadata/ as .md-meta.xml files

## OVF Page Layout
- Current sections: Information, Sales Rep Entry, System Information, Custom Links
- No "Marketplace" section exists yet -- existing marketplace fields (Azure_Subscription_Id__c, Marketplace_Plan__c, Marketplace_Amount__c, Subscription_End_Date__c) are NOT on the layout
- New marketplace fields should be added to a new "Marketplace" section between "Sales Rep Entry" and "System Information"
