# Unit Testing Agent Memory Index

- [CaseDemoController patterns](case_demo_controller_patterns.md) — ServiceContract.GrandTotal is a rollup (needs ContractLineItem); Status='Active' is a custom picklist value; isNew 90-day boundary; WITH USER_MODE works under System Admin test context

- [OrderMainTriggerTest patterns](project_order_trigger_test_patterns.md) — Key patterns for extending OrderMainTriggerTest: helper methods, Product2/PricebookEntry setup, Polaris provisioning assertions
- [SBQQ Quote test patterns](sbqq_quote_test_patterns.md) — How to insert SBQQ__Quote__c with PrimaryContact for email-match tests; trigger bypass strategy; OVF__c setup
- [SendOvfEmailController patterns](send_ovf_email_test_patterns.md) — AuraHandledException dual-check, @TestVisible method calls, null-field QuoteLine, HTML escaping assertions
- [Exception type migration pattern](exception_type_migration.md) — When a controller changes from AuraHandledException to IllegalArgumentException/CalloutException, update test catch blocks to match the new type exactly
- [RubrikQuoteLookupController dynamic OVF patterns](rubrik_quote_lookup_dynamic_ovf_patterns.md) — submitOVFDynamic JSON testing, instance method instantiation, field set null-safe assertions
- [OrderInsertHelper guard condition coverage](order_insert_helper_guard_patterns.md) — How to exercise Revenue/POC callout guards in their blocking direction; status transition sequencing; RSC_G_Enabled__c boundary testing
- [CSV controller test patterns](csv_controller_test_patterns.md) — Testing CSV-parsing Apex controllers: header-missing exceptions, column-order independence, blank-row transparency, bulk de-duplication via Map, @TestVisible private helpers
- [Email parser test patterns](email_parser_test_patterns.md) — Testing InboundEmailHandler + utility pattern: Messaging.InboundEmail construction, AuraHandledException boolean-catch, non-allowlist key tests, invalid-date skip path, log record field assertions
- [OVF Stage PO Queueable test patterns](ovf_stage_po_test_patterns.md) — Queueable testing via trigger firing, flowcontroll gate, OVFTriggerHandler static flag reset, Disable_StagePO_Trigger__c, PO_Stage__c minimum fields, bulk 10-record pattern
