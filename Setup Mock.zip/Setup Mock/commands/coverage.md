Check Apex test coverage for the org or a specific class: $ARGUMENTS

## What this command does

Queries the org's code coverage data and surfaces classes below the 75% deployment threshold. Run this before a release window or after new Apex has been written to catch coverage gaps early.

---

## Step 1 — Parse arguments

`$ARGUMENTS` can be:
- Empty → check overall org coverage summary
- A class name (e.g., `AccountTriggerHandler`) → check that specific class only
- `--low` → list only classes below 75%
- `--all` → full list sorted by coverage % ascending

Default (no args): show org summary + list all classes below 75%.

---

## Step 2 — Query coverage via Salesforce MCP

Use `mcp__salesforce__execute_soql` to run:

```sql
-- Overall org coverage
SELECT NumLinesCovered, NumLinesUncovered 
FROM ApexOrgWideCoverage

-- Per-class coverage (all classes)
SELECT ApexClassOrTrigger.Name, NumLinesCovered, NumLinesUncovered,
       (NumLinesCovered / (NumLinesCovered + NumLinesUncovered) * 100) coverage
FROM ApexCodeCoverageAggregate
ORDER BY coverage ASC
LIMIT 200
```

If checking a specific class, filter:
```sql
WHERE ApexClassOrTrigger.Name = '[ClassName]'
```

---

## Step 3 — Calculate and display results

Compute for each class:
- `coverage %` = `NumLinesCovered / (NumLinesCovered + NumLinesUncovered) * 100`
- Flag as ❌ if below 75%, ⚠️ if 75–80%, ✅ if above 80%

Output in this format:

```
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
 APEX COVERAGE REPORT — RubrikClaudePOC
 [date/time]
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

ORG OVERALL: [X]% ([N] lines covered / [M] total)
STATUS: [✅ Deployment-ready / ❌ Below 75% threshold]

CLASSES BELOW 75% (deployment blockers):
  ❌ [ClassName]           [X]%   ([N] covered / [M] total)
  ❌ [ClassName]           [X]%   ([N] covered / [M] total)

CLASSES BETWEEN 75–80% (at risk):
  ⚠️  [ClassName]          [X]%

TOP 5 LOWEST COVERAGE:
  1. [ClassName]  [X]%
  2. [ClassName]  [X]%
  ...

RECOMMENDATION:
  [Safe to deploy / Fix [N] classes before deploying / Run unit-testing agent for [ClassName]]
```

---

## Step 4 — Offer remediation

If any classes are below 75%, ask:

> "Found [N] class(es) below the 75% threshold. Do you want to:
> (a) Write tests for a specific class — I'll route to the unit-testing agent
> (b) See the uncovered lines for a class — I'll read the source and coverage detail
> (c) No action needed right now"

If option (a) — invoke the `salesforce-unit-testing` subagent:
```
Write or improve test coverage for [ClassName]. 
Current coverage: [X]%. Target: 85%+.
Read the class first, identify untested scenarios, and add test methods to the existing test class (or create one if none exists).
```
