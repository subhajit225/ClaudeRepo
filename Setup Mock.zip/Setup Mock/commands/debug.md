Debug a Salesforce error or exception: $ARGUMENTS

## What this command does

Takes an exception message, stack trace, or deployment error and routes it straight to the developer agent — with the offending class already read and context pre-loaded. No design gate, no admin agent. Fix-only pipeline.

---

## Step 1 — Parse the error

Extract from `$ARGUMENTS`:
- **Error type** (e.g., `NullPointerException`, `FIELD_CUSTOM_VALIDATION_EXCEPTION`, `CANNOT_INSERT_UPDATE_ACTIVATE_ENTITY`, deployment compile error, test failure)
- **Class name** — look for patterns like `Class.ClassName.methodName:` or `line N, column M`
- **Line number** (if present)
- **Object/field mentioned** (if a DML or validation error)

If `$ARGUMENTS` is empty, ask: "Paste the error message or stack trace you want to debug."

---

## Step 2 — Locate the offending file(s)

```bash
# Find the class
find force-app/main/default/classes -name "[ClassName].cls" -not -name "*.xml"

# Find the trigger (if trigger error)
find force-app/main/default/triggers -name "[TriggerName].trigger" -not -name "*.xml"

# Find the test class (if test failure)
find force-app/main/default/classes -name "[TestClassName].cls" -not -name "*.xml"
```

Read the file(s). If a line number is mentioned, focus on ±20 lines around that line.

---

## Step 3 — Classify the error

| Error pattern | Likely cause |
|---------------|-------------|
| `NullPointerException` | Unguarded null — missing null check before `.get()` / field access |
| `List has no rows for assignment` | SOQL returning empty, assigned to single SObject |
| `CANNOT_INSERT_UPDATE_ACTIVATE_ENTITY` | Trigger recursion or validation rule |
| `System.LimitException: Too many SOQL queries` | SOQL inside loop |
| `FIELD_CUSTOM_VALIDATION_EXCEPTION` | Validation rule blocking DML — check object validation rules |
| Compile error: `Variable does not exist` | Wrong API name, missing import, or scope issue |
| Test failure: `Assertion failed` | Test data setup issue or logic regression |
| Deployment error: `Cannot modify managed` | Trying to modify locked managed package component |

---

## Step 4 — Route to Developer Agent

Invoke the `salesforce-developer` subagent with this prompt:

```
Fix the following error in the Salesforce codebase.

ERROR:
[paste full error text from $ARGUMENTS]

OFFENDING FILE: [ClassName].cls (or trigger name)

FILE CONTENT (around line [N]):
[paste relevant excerpt]

INSTRUCTIONS:
- Fix only what is broken. Do not refactor unrelated code.
- If the fix requires a null guard, add it with a clear inline comment.
- If the fix requires a SOQL to move outside a loop, restructure the minimal necessary code.
- After fixing, confirm: "Fix applied. Here is what changed and why."
- If Apex was modified: flag for unit testing (user will decide whether to run /coverage after).
- Do NOT invoke design or admin agents. This is a targeted fix only.
```

---

## Step 5 — Post-fix check

After the developer agent responds, ask:

> "Fix applied. Do you want to:
> (a) Deploy now — route to devops agent
> (b) Run coverage check first — run /coverage
> (c) Review the fix manually — no further action"
