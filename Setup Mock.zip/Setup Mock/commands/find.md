Search the RubrikClaudePOC codebase for components matching: $ARGUMENTS

Search across all relevant directories and return a structured summary of what exists.

---

## Search Locations

Run all searches under `force-app/main/default/`:

```bash
# Apex classes
find force-app/main/default/classes -iname "*$ARGUMENTS*" -not -name "*.xml"

# Triggers
find force-app/main/default/triggers -iname "*$ARGUMENTS*" -not -name "*.xml"

# LWC components
find force-app/main/default/lwc -iname "*$ARGUMENTS*" -type f

# Aura components
find force-app/main/default/aura -iname "*$ARGUMENTS*" -type f

# Objects and fields
find force-app/main/default/objects -iname "*$ARGUMENTS*"

# Custom metadata
find force-app/main/default/customMetadata -iname "*$ARGUMENTS*"
```

Also search inside file contents for references:

```bash
grep -rl "$ARGUMENTS" force-app/main/default/classes --include="*.cls" -l
grep -rl "$ARGUMENTS" force-app/main/default/triggers --include="*.trigger" -l
grep -rl "$ARGUMENTS" force-app/main/default/lwc --include="*.js" -l
```

---

## Output Format

Return results grouped by type:

```
📦 APEX CLASSES
  - ClassName.cls (path)
    [First 3 lines of class declaration]

⚡ TRIGGERS
  - TriggerName.trigger (path)
    [Trigger signature line]

🖥️  LWC COMPONENTS
  - componentName/ (path)
    [Files in the component bundle]

🗃️  OBJECTS / FIELDS
  - ObjectName__c or FieldName__c (path)

🔗 REFERENCED IN
  - Files that reference this component (from grep results)
```

If nothing is found, say so clearly and suggest alternative search terms (e.g. partial name, different casing, related domain prefix like `lCC_`, `sU_`, `pc_`).

---

## After Results

If exactly one Apex class or trigger is found, offer:
> "Want me to read and summarize what this component does?"

If multiple components are found, ask:
> "Which one do you want to look at?"
