Perform a full dependency analysis for the component named: $ARGUMENTS

## What this command does

Before modifying any class, trigger, LWC, or object in a 2000+ class codebase, you need to know everything that depends on it. This command searches the entire codebase for references and produces a dependency map so the design agent can make safe, informed decisions.

---

## Step 1 — Identify the component

Parse `$ARGUMENTS` to extract the component name. Examples:
- `AccountTriggerHandler` → Apex class
- `Account` → could be object, trigger, or both
- `opportunityCard` → LWC
- `Contract__c` → custom object

If no argument is provided, ask: "Which component do you want to analyze? (class name, trigger name, LWC folder name, or object API name)"

---

## Step 2 — Search for the component itself

Locate the source file(s):

```bash
# Apex class
find force-app/main/default/classes -name "$ARGUMENTS.cls" -not -name "*.xml"

# Apex trigger
find force-app/main/default/triggers -name "$ARGUMENTS*.trigger" -not -name "*.xml"

# LWC
find force-app/main/default/lwc -iname "*$ARGUMENTS*" -type d

# Custom object
find force-app/main/default/objects -maxdepth 1 -iname "$ARGUMENTS*" -type d

# Custom metadata type
find force-app/main/default/customMetadata -iname "*$ARGUMENTS*"
```

Read the component file(s) if found. If not found, warn the user: "Component not found in force-app/. Proceeding with reference search only."

---

## Step 3 — Find all references across the codebase

Run these searches in sequence:

```bash
# All Apex classes that reference this component
grep -rl "$ARGUMENTS" force-app/main/default/classes --include="*.cls" -l

# All triggers that reference it
grep -rl "$ARGUMENTS" force-app/main/default/triggers --include="*.trigger" -l

# All LWC JS files that reference it (Apex method imports, wire adapters)
grep -rl "$ARGUMENTS" force-app/main/default/lwc --include="*.js" -l

# All LWC HTML templates that reference it (component tags)
grep -rl "$ARGUMENTS" force-app/main/default/lwc --include="*.html" -l

# All flows that reference it
grep -rl "$ARGUMENTS" force-app/main/default/flows --include="*.flow-meta.xml" -l

# All permission sets that reference it
grep -rl "$ARGUMENTS" force-app/main/default/permissionsets --include="*.permissionset-meta.xml" -l

# All custom metadata records that reference it
grep -rl "$ARGUMENTS" force-app/main/default/customMetadata --include="*.md-meta.xml" -l
```

Read the top 5 most-referenced files to understand how this component is used.

---

## Step 4 — Produce the Impact Report

Output a structured report in this format:

```
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
 IMPACT ANALYSIS — [ComponentName]
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

COMPONENT TYPE: [Apex Class / Trigger / LWC / Object / Custom Metadata]
LOCATION: [file path]

DIRECT REFERENCES:
  Apex Classes  : [count] — [list names]
  Triggers      : [count] — [list names]
  LWC           : [count] — [list component folders]
  Flows         : [count] — [list names]
  Permission Sets: [count] — [list names]
  Custom Metadata: [count] — [list names]

RISK ASSESSMENT:
  [LOW / MEDIUM / HIGH] — based on number of dependencies

  HIGH   = 10+ references or referenced by a trigger
  MEDIUM = 3–9 references
  LOW    = 1–2 references or no references found

SAFE TO MODIFY?
  [Yes — low blast radius / Caution — review dependents first / High risk — changes will cascade]

RECOMMENDED NEXT STEPS:
  [Bullet list — e.g., "Read AccountService.cls before modifying", "Coordinate with LWC changes in opportunityCard"]
```

---

## Step 5 — Route to Design Agent (optional)

After printing the report, ask the user:

> "Do you want to proceed with a design for changes to [ComponentName]? (yes / no)"

If yes — invoke the `salesforce-design` subagent with:
- The impact report as context
- The user's original change request (ask if not yet provided)
- Instruction: "You have the full dependency map below. Factor all dependents into your design."
