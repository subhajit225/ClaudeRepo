Redeploy an existing, already-reviewed Salesforce component. Routes directly to the devops agent — no design, no development, no code review.

Component to redeploy: $ARGUMENTS

---

## When to use this

- A deployment previously failed and needs to be retried
- A component was deployed to the wrong org and needs redeployment
- A rollback was applied and the component needs to be redeployed
- Any redeployment of a component that has already passed code review

Do NOT use this for new changes. If the component has been modified since last deployment, use the full workflow or `/hotfix` instead.

---

## Step 1 — Confirm the component exists

```bash
find force-app/main/default -name "$ARGUMENTS*" -not -name "*.xml"
```

If not found, stop and report. Do not proceed with a deployment against a component that cannot be located in source.

---

## Step 2 — Show what will be deployed

Before routing to devops, display:
- Full file path of the component
- Last modified date (`git log -1 --format="%ci" -- [filepath]`)
- Last commit message (`git log -1 --format="%s" -- [filepath]`)

Ask: "Confirm redeployment of [ComponentName] (last changed: [date] — [commit message])? (yes / no)"

---

## Step 3 — Devops agent

After confirmation:

```
Use the salesforce-devops subagent to redeploy [ComponentName].
Target org: RubrikClaudePOC. Environment: Sandbox.
This is a redeployment of an existing component — the component has already passed code review.
Locate the component, confirm the deploy package, and output the DEPLOY INSTRUCTION block.
```

After the devops agent outputs its DEPLOY INSTRUCTION block, execute deployment via `mcp__salesforce__deploy_metadata`.

---

## Step 4 — Verify deployment landed

After deployment completes, run a Tooling API query to confirm the component exists in the org — do not trust the deploy result alone (per devops agent memory: deployment-verification.md).

```
mcp__salesforce__run_soql_query:
SELECT Id, Name, LastModifiedDate FROM ApexClass WHERE Name = '[ComponentName]'
(adjust object type for triggers, LWC, etc.)
```

Report the result.
