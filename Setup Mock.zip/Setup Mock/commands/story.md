Fetch the Jira issue $ARGUMENTS and route it through the Salesforce development pipeline.

## Step 1 — Fetch the Jira issue

Call `mcp__mcp-atlassian__jira_get_issue` with the issue key provided (e.g. PROJ-123).

Extract:
- Summary (story title)
- Description (full requirements)
- Acceptance criteria (if present in description or a dedicated field)
- Issue type (Story / Bug / Task)
- Priority
- Any linked issues or dependencies mentioned

If the issue cannot be fetched, stop and report the error.

---

## Step 2 — Format for the design agent

Construct a clean requirements prompt from what was fetched. Do not paraphrase or expand — use the exact language from the Jira issue. Structure it as:

```
Story: [Summary]
Type: [Issue type]
Priority: [Priority]

Requirements:
[Description text]

Acceptance Criteria:
[Acceptance criteria if present, otherwise "Not specified"]
```

---

## Step 3 — Route to salesforce-design

Pass the formatted requirements to the design agent:

```
Use the salesforce-design subagent to analyze this request: [formatted requirements]
```

---

## Step 4 — Gate 1

Present the design output and ask: "Proceed? (yes / no / changes)"

If yes, continue with the standard 7-agent workflow from Step 3 onward (developer → unit-testing → code-review → devops + docs in parallel).

After deployment and documentation are complete, attach the generated doc to the Jira issue and add a comment:
> "Design document attached. Deployment completed successfully. See attached file for full implementation details."
